<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ProductReview;
use DB;
class ProductReviewController extends Controller
{

	public function __construct()
    {
        $this->middleware('auth');
    }

    public function manegeProductReview()
    {
        $productReviews = ProductReview::all();
    	return view('admin.product.productReview',['productReviews'=> $productReviews ]);
    }


    public function saveProductReview(Request $request)
    {
    	$productReview = new ProductReview();

    	// dd($request->all());
    	// exit();

    	
    	$productReview->reviewer_name  = $request->reviewName;
    	$productReview->reviewer_email  = $request->reviewEmail;
    	$productReview->reviewer_message  = $request->reviewMessage;
    	$productReview->review_productID = $request->productId;
    	$productReview->review_productName = $request->productName;



    	$productReview->save();

    	return redirect('/');

    }

   

    public function viewProductReview($id)
    {  

    	 $productReviewById = DB::table('product_reviews')
        ->join('products','product_reviews.review_productID','=','products.id')

        ->select('product_reviews.*', 'products.productImage', 'products.productPrice')
        ->where('product_reviews.id',$id)
        ->first();

        //  echo "<pre>";
        // print_r($productReviewById);
        // exit();



    	return view('admin.product.viewproductReview',['productReview'=> $productReviewById]);
    }

    public function deleteProductReview($id)
    {
         $productReview = ProductReview::find($id);
         $productReview->delete();
         return redirect('/productReview/manage')->with('message','Product Review Info Delete Successfully..!!');

    }

}
