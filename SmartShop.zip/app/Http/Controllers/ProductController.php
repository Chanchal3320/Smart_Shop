<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Manufacture;
use App\Product;
use DB;

class ProductController extends Controller
{

 public function __construct()
    {
        $this->middleware('auth'); 
    }

    
    public function createProduct()
    {
        $categories = Category::where('publicationStatus','1')->get();
        $manufacturers = Manufacture::where('publicationStatus','1')->get();
        return view('admin.product.createProduct',['categories'=>$categories,'manufacturers'=>$manufacturers]);
    }

   
    public function storeProduct(Request $request)
    {
        //return $request->all();

        $this->validate($request,[
            'productName'=>'required',            
            'productPrice'=>'required',
            'productQuantity'=>'required',
            'productShortDescription'=>'required',
            'productImage'=>'required',
        ]);



       $productImage = $request->file('productImage');
       // echo '<pre>';
       // print_r($productImage);

       $imageName= $productImage->getClientOriginalName();
       //echo $imagetName;

       $uploadPath='productImage/';


       $productImage->move($uploadPath,$imageName);
       $imageURL=$uploadPath.$imageName;
       $this->saveProductInfo($request,$imageURL);
       return redirect('/product/add')->with('message','Product Info Save Successfully..!!');
   }
 protected function saveProductInfo($request,$imageURL)
    {
        $product = new Product();
       $product->productName = $request->productName;
       $product->categoryId = $request->categoryId;
       $product->manufacturerId = $request->manufacturerId;
       $product->productPrice = $request->productPrice;
       $product->productQuantity = $request->productQuantity;
       $product->productShortDescription = strip_tags($request->productShortDescription);
       $product->productLongDescription = strip_tags($request->productLongDescription);
       $product->productImage = $imageURL;
       $product->publicationStatus = $request->publicationStatus;
       $product->save();
    }
      

    public function manegeProduct()
    {
        $products= DB::table('products')
        ->join('categories','products.categoryId','=','categories.id')
        ->join('manufactures','products.manufacturerId','=','manufactures.id')
        ->select('products.id','products.productName','products.productPrice','products.productQuantity','products.publicationStatus', 'categories.categoryName', 'manufactures.manufacturerName')
        ->get();
        // echo "<pre>";
        // print_r($product);
        // exit(); 


        //$product = Product::all();
        return view('admin.product.manageProduct',['products'=>$products]); 
    } 

    public function viewProduct($id)
    {
        $productById = DB::table('products')
        ->join('categories','products.categoryId','=','categories.id')
        ->join('manufactures','products.manufacturerId','=','manufactures.id')
        ->select('products.*', 'categories.categoryName', 'manufactures.manufacturerName')
        ->where('products.id',$id)
        ->first();

        // echo "<pre>";
        // print_r($productById);
        // exit();


            return view('admin.product.viewProduct',['product'=> $productById]);
    }
    

    public function editProduct($id)
    {   

        // $productById = Product::where('id',$id)->first();
        //  return view('admin.product.editProduct',['productById'=>$productById]);

        $categories = Category::where('publicationStatus','1')->get();
        $manufacturers = Manufacture::where('publicationStatus','1')->get();
        $productById = Product::where('id',$id)->first();
     
       
        
        

        return view('admin.product.editProduct',['productById'=>$productById , 'categories'=>$categories,
            'manufacturers'=>$manufacturers]);

    }

    public function updateProduct(Request $request)
    {
    

    $imageURL= $this->imageExistStatus($request);  
    $this->updateProductInfo($request,$imageURL);
       return redirect('/product/manage')->with('message','Product Update  Successfully..!!');
     }


private function imageExistStatus($request)
{ 
    $productById = Product::where('id',$request->productId)->first();
    
    $productImage= $request->file('productImage');

    if ($productImage) {
        $oldImageURL = $productById->productImage;

        unlink($oldImageURL);
        $imageName= $productImage->getClientOriginalName();
        //echo $imageName;

         $uploadPath='productImage/';


         $productImage->move($uploadPath,$imageName);
          $imageURL=$uploadPath.$imageName;

         
         
         }

         else {
            $imageURL = $productById->productImage;

         }
         return $imageURL;
}


     protected function updateProductInfo($request,$imageURL)
    {
        $product =Product::find($request->productId);
       $product->productName = $request->productName;
       $product->categoryId = $request->categoryId;
       $product->manufacturerId = $request->manufacturerId;
       $product->productPrice = $request->productPrice;
       $product->productQuantity = $request->productQuantity;
       $product->productShortDescription = strip_tags($request->productShortDescription);
       $product->productLongDescription = strip_tags($request->productLongDescription);
       $product->productImage = $imageURL;
       $product->publicationStatus = $request->publicationStatus;
       $product->save();
    }

    public function deleteProduct($id)
    {
         $product = Product::find($id);
         $product->delete();
         return redirect('/product/manage')->with('message','Product Info Delete Successfully..!!');
    }

}
