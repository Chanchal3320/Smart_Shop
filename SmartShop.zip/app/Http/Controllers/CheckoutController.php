<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Customer;
use App\Shipping;
use App\Order;
use App\Payment;
use App\OrderDetail;
use Session;
use Cart;
use Auth;

class CheckoutController extends Controller
{
    

    
    public function index()
    {
    	return view('frontEnd.checkout.checkoutContent');
    }


   

    public function showShippingForm()
    {
    	$customerId=Session::get('customerId');
    	$customerById = Customer::find($customerId);
    	return view('frontEnd.checkout.shippingContent',['customerById'=>$customerById]);

    }

    public function saveShippingInfo(Request $request)
    {
    	$shipping = new Shipping();
    	$shipping->fullName = $request->fullName;
    	
    	$shipping->emailAddress = $request->emailAddress;
    	$shipping->phoneNo = $request->phoneNo;
    	$shipping->address = $request->address;
    	$shipping->distName = $request->distName;

    	$shipping->save();

    	$shippingId = $shipping->id;

    	Session::put('shippingId',$shippingId);
    	return redirect('/checkout/payment');

    }

    public function showPaymentForm()
    {
    	return view('frontEnd.checkout.paymentContent');

    }

    public function saveOrderInfo(Request $request)
    {
    	$paymentType = $request->paymentType;  

    	if($paymentType =='cashOnDelivery'){
    		$order = new Order();
    		$order->customerId  =  Session::get('customerId');
    		$order->shippingId  = Session::get('shippingId');
    		$order->orderTotal  = Session::get('orderTotal');
    		$order->save();

    		$orderId = $order->id;

    		Session::put('orderId',$orderId);


    		$payment = new Payment();
    		$payment->orderId = Session::get('orderId');
    		$payment->paymentType = $paymentType;
    		$payment->save();

    		$orderDetail = new OrderDetail();
    		$CartProducts= Cart::content();

    		foreach ($CartProducts as $CartProduct) {
			$orderDetail-> orderId =  Session::get('orderId');
    		$orderDetail-> productId = $CartProduct->id;
    		$orderDetail-> productName = $CartProduct->name;
    		$orderDetail-> productPrice = $CartProduct->price;
    		$orderDetail-> productQuantity = $CartProduct->qty;

    		$orderDetail->save();

    		Cart::remove($CartProduct->rowId);

    		}
    		

    		return redirect('/check/my-home');



    	}
    	else if ($paymentType =='bkash') {
    		echo 'Uder Construction B-kash Payment';
    	}
    	else if ($paymentType =='paypal') {
		return 'Uder Construction Paypal Payment';

    	}


    }

    public function customerHome()
    {
    	return view('frontEnd.customer.customerHome');
    }


  
   
}
