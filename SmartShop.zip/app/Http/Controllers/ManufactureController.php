<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Manufacture;

class ManufactureController extends Controller
{

   public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function createManufacture()
    {
    	return view ('admin.manufacture.createManufacture');
    }


    public function storeManufacture(Request $request)
    {
    	$this->validate($request,[
    		'manufacturerName'=>'required',
    		'manufacturerDescription'=>'required',

    	]);


    	$manufacture = new Manufacture();
    	$manufacture->manufacturerName = $request->manufacturerName;
    	$manufacture->manufacturerDescription = strip_tags($request->manufacturerDescription);
    	$manufacture->publicationStatus = strip_tags($request->publicationStatus);
    	$manufacture->save();


    	return redirect('/manufacture/add')->with('message','Manufacturer Info Save Successfully..!!');

    }


    public function manegeManufacture()
    {
    	$manufacture = Manufacture::all();
    	return view('admin.manufacture.manageManufacture',['manufactures'=>$manufacture]);

    }

   public function editManufacture($id)
   {
   	//return $id;
   	$manufactureById = Manufacture::where('id',$id)->first();
	return view('admin.manufacture.editManufacture',['manufactureById'=>$manufactureById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }



   public function updateManufacture(Request $request)
   {
   	 //dd($request->all());


    	$manufacture = Manufacture::find($request->manufaturerId);
    	
    	$manufacture->manufacturerName = $request->manufacturerName;
    	$manufacture->manufacturerDescription = strip_tags($request->manufacturerDescription);
    	$manufacture->publicationStatus = strip_tags($request->publicationStatus);
    	$manufacture->save();
    	return redirect('/manufacture/manage')->with('message','Manufacturer Info Update Successfully..!!');

   }


   public function deleteManufacture($id)
   {
   	 $category = Manufacture::find($id);
   	 $category->delete();
   	 return redirect('/manufacture/manage')->with('message','Manufacturer Info Delete Successfully..!!');


   }
}
