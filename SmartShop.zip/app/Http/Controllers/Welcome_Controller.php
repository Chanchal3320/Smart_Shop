<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;


class Welcome_Controller extends Controller
{
   function index()
   {
   		// //echo "Chanchal";
   		// return view ('demo');

    $publishProducts = Product::where('publicationStatus',1)->get();

   	return view('frontEnd.home.homeContent',['publishProducts'=> $publishProducts]);

   }

   function category($id) 
   {
      $publishedCategoryProducts = Product::where('categoryId',$id)
                                 ->where('publicationStatus',1)
                                 ->get();

       return view('frontEnd.category.categoryContent',['publishedCategoryProducts'=>$publishedCategoryProducts]);
   }

   function contact()
   {
       return view('frontEnd.contact.contactContent');
   }

   function productDetails($id )
   {
    $ProductById = Product::where('id',$id)->first();
   	 return view('frontEnd.product.product_details',['ProductById'=>$ProductById ]);
   }

  public function viewCategory()
  {
    $categories = Category::where('id',$id)->get();

    
  }


  public function menuElectronics()
  {
    
    return view('frontEnd.product.electronics');
  }


      




}
