<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Product;
use Cart;

class CartController extends Controller
{
     function addToCart(Request $request)
    {
    	//dd($request->all());


    	$productId = $request->productId;
    	$productById = Product::where('id',$productId)->first();

    	Cart::add([
    		'id'=>$productId,
    		'name'=>$productById->productName,
    		'price'=>$productById->productPrice,
    		'qty'=>$request->qty



    	]);


    	return redirect('/show-cart');



    }

    public function cartShow()
    {
    	$cartProducts = Cart::Content();
    	return view('frontEnd.cart.cartShow',['cartProducts'=>$cartProducts]);
    }


    public function updateCart(Request $request)
    {
    	Cart::update($request->rowId,$request->qty);

    	return redirect('/show-cart')->with('message','Cart Product Update Successfully..!!');


    }


    public function deleteCart($rowId)
    {
    	Cart::remove($rowId);
    	return redirect('/show-cart')->with('message','Cart Product  Delete Successfully..!!');

    }
}
