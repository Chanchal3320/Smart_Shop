<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Customer;
use Illuminate\Validation\ValidationException;
use Session;
use App\CustomerLogin; 

use DB;


class CustomerLoginController extends Controller
{
    public function customerSignUp(Request $request)
    {        
    	$customer = new Customer();
    	$customer->firstName = $request->firstName;
    	$customer->lastName = $request->lastName;
    	$customer->emailAddress = $request->emailAddress;
    	$customer->phoneNo = $request->phoneNo;
    	$customer->address = $request->address;
    	$customer->distName = $request->distName;
    	$customer->password = bcrypt($request->password);

    	$customer->save();

    	$customerId = $customer->id; 

    	Session::put('customerId',$customerId); 
    	return redirect('/checkout/shipping');

    }
 

public function customerSignIn(Request $request)
 {
     // dd($request->all());

     // exit();

    //Validate the form 
    // $this->validate($request,[
    //     'emailAddress' => 'required|email',
    //     'password' => 'required|min:6',

    // ]);



         $customerEmail = $request->emailAddress;
         $customerPassword = bcrypt($request->password);
        $customerId = Customer::where ('emailAddress',$customerEmail)
                    ->where ('password',$customerPassword)
                    ->first();

        $customerId = $customerId->id;


        // $customerId=DB::table('customers')
        //         ->where('emailAddress',$customerEmail)
        //         ->where('password',$customerPassword)
        //         ->first();


         if ($customerId) {
           

            Session::put('firstName ',$customerId->firstName);
          Session::put('customerId',$customerId);
               

             return redirect('/checkout/shipping');

         }

         else{
            
            return redirect('/customerSignIn')->with('message','Email Or Password Invalid..!!');
         }
 }


 public function customerSignInForm()
 {
     return view('frontEnd.checkout.checkoutContent');
 }


 public function customerLogout()
 {
     Session::flash();

        return redirect('/');
 }

  
}
