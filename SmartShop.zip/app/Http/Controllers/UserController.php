<?php

 namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\User;




class UserController extends Controller
{
  

 public function __construct()
    {
        $this->middleware('auth');
    }
    


     public function manegeUser()
    {
    	$users= User::paginate();
    	return view('admin.user.manageUser',['users'=>$users]);

    }

      public function editUser($id)
   {
   	//return $id;
   	$userById = User::where('id',$id)->first();
	return view('admin.user.editUser',['userById'=>$userById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }

   public function updateUser(Request $request)
   {
   	 


    	$user = User::find($request->userId);
    	$user->name = $request->name;
    	$user->email = $request->email;
    	$user->address = $request->address;
    	$user->save();
    	return redirect('/user/manage')->with('message','User Info Update Successfully..!!');

   }

   public function deleteUser($id)
   {
   	 $user = User::find($id);
   	 $user->delete();
   	 return redirect('/user/manage')->with('message','User Info Delete Successfully..!!');


   }
}
