<?php
  
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use DB;

class CategoryController extends Controller 
{
 public function __construct()
    {
        $this->middleware('auth');
    }
  


     public function createCategory()
    {
    	return view('admin.category.createCategory');
    }



    public function storeCategory(Request $request)
    {

    	$this->validate($request,[
    		'categoryName'=>'required',
    		'categoryDescription'=>'required',

    	]);

    	// return $request->all();

    	/* First process  -> Elequent ORM*/
    	$category = new Category();
    	$category->categoryName = $request->categoryName;
    	$category->categoryDescription = strip_tags($request->categoryDescription);
    	$category->publicationStatus = strip_tags($request->publicationStatus);
    	$category->save();

    	// return redirect('/catagory/add')->with('message','Category Info Save Successfully..!!');

    	

    	// /* Second Process -> Elequent ORM */
    	// Category::create($request->all());
    	// return 'Category Info Save Successfully..!!';


    	/* Third Process -> Query Builder */
    	// DB::table('categories')->insert([

    	// 	'categoryName'=>$request->categoryName,
    	// 	'categoryDescription'=>$request->categoryDescription,
    	// 	'publicationStatus'=>$request->publicationStatus,


    	// ]);
    	//return 'Category Info Save Successfully..!!';

    	return redirect('/category/add')->with('message','Category Info Save Successfully..!!');

    }



    public function manegeCategory()
    {
    	$categories = Category::all();
    	return view('admin.category.manageCategory',['categories'=>$categories]);

    }

   public function editCategory($id)
   {
   	//return $id;
   	$categoryById = Category::where('id',$id)->first();
	return view('admin.category.editCategory',['categoryById'=>$categoryById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }



   public function updateCategory(Request $request)
   {
   	 //dd($request->all());

   		/* First process  -> Elequent ORM*/
    	// $category = new Category();
    	// $category->categoryName = $request->categoryName;
    	// $category->categoryDescription = $request->categoryDescription;
    	// $category->publicationStatus = $request->publicationStatus;
    	// $category->update();


    	$category = Category::find($request->categoryId);
    	$category->categoryName = $request->categoryName;
    	$category->categoryDescription = strip_tags($request->categoryDescription);
    	$category->publicationStatus =strip_tags($request->publicationStatus);
    	$category->save();
    	return redirect('/category/manage')->with('message','Category Info Update Successfully..!!');

   }


   public function deleteCategory($id)
   {
   	 $category = Category::find($id);
   	 $category->delete();
   	 return redirect('/category/manage')->with('message','Category Info Delete Successfully..!!');


   }
}
