<?php $__env->startSection('title'); ?>
Smart Shop || Product Details
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>
<!-- //banner-top -->
<!-- banner -->
<div class="page-head">
	<div class="container">
		<h3>Single</h3>
	</div>
</div>
<!-- //banner -->
<!-- single -->
<div class="single">
	<div class="container">
		<div class="col-md-6 single-right-left animated wow slideInUp animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: slideInUp;">
			<div class="grid images_3_of_2">
				<div class="flexslider">
					<!-- FlexSlider -->
						<script>
						// Can also be used with $(document).ready()
							$(window).load(function() {
								$('.flexslider').flexslider({
								animation: "slide",
								controlNav: "thumbnails"
								});
							});
						</script>
					<!-- //FlexSlider-->
					<ul class="slides">
						<li data-thumb="<?php echo e(asset($ProductById->productImage)); ?>">
							<div class="thumb-image"> <img src="<?php echo e(asset($ProductById->productImage)); ?>" data-imagezoom="true" class="img-responsive"> </div>
						</li>
						<li data-thumb="<?php echo e(asset($ProductById->productImage)); ?>">
							<div class="thumb-image"> <img src="<?php echo e(asset($ProductById->productImage)); ?>" data-imagezoom="true" class="img-responsive"> </div>
						</li>	
						<li data-thumb="<?php echo e(asset($ProductById->productImage)); ?>">
							<div class="thumb-image"> <img src="<?php echo e(asset($ProductById->productImage)); ?>" data-imagezoom="true" class="img-responsive"> </div>
						</li>
						<li data-thumb="<?php echo e(asset($ProductById->productImage)); ?>">
							<div class="thumb-image"> <img src="<?php echo e(asset($ProductById->productImage)); ?>" data-imagezoom="true" class="img-responsive"> </div>
						</li>	
					</ul>
					<div class="clearfix"></div>
				</div>	
			</div>
		</div>
		<div class="col-md-6 single-right-left simpleCart_shelfItem animated wow slideInRight animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: slideInRight;">
					<h3><?php echo e($ProductById->productName); ?></h3>
					<p><span class="item_price">BDT <?php echo e($ProductById->productPrice); ?></p>
					<div class="rating1">
						<span class="starRating">
							<input id="rating5" type="radio" name="rating" value="5">
							<label for="rating5">5</label>
							<input id="rating4" type="radio" name="rating" value="4">
							<label for="rating4">4</label>
							<input id="rating3" type="radio" name="rating" value="3" checked="">
							<label for="rating3">3</label>
							<input id="rating2" type="radio" name="rating" value="2">
							<label for="rating2">2</label>
							<input id="rating1" type="radio" name="rating" value="1">
							<label for="rating1">1</label>
						</span>
					</div>
					<div class="description">
						<h5><?php echo e($ProductById->productDescription); ?></h5>
						<input type="text" value="Enter pincode" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter pincode';}" required="">
						<input type="submit" value="Check">
					</div>
					

					
					
					<?php echo Form::open(['url' => '/cart-add' ,'method'=>'POST']); ?>


					<div class="color-quality">
						<div class="color-quality-right">
							<h5>Quality :</h5>
							<input type="number" min="1" id="qty"  name="qty" class="form-control" >
						</div>
					</div>

						<input type="hidden" value="<?php echo e($ProductById->id); ?>" name="productId" id="productId">
						<input type="hidden" name="quantity" value="1" >
					<button type="submit" class="item_add single-item hvr-outline-out button2" >Add To Cart </button>


					<?php echo Form::close(); ?>	
					
		</div>
		
				<div class="clearfix"> </div>

		<div class="bootstrap-tab animated wow slideInUp animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: slideInUp;">
			<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
				<ul id="myTab" class="nav nav-tabs" role="tablist">
					<li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Description</a></li>
					<li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">Reviews</a></li>
					
				</ul>
				<div id="myTabContent" class="tab-content">
					<div role="tabpanel" class="tab-pane fade in active bootstrap-tab-text" id="home" aria-labelledby="home-tab">
						<h5>Product Brief Description</h5>
						<p><?php echo $ProductById->productLongDescription; ?></p>
					</div>
					<div role="tabpanel" class="tab-pane fade bootstrap-tab-text" id="profile" aria-labelledby="profile-tab">
						<div class="bootstrap-tab-text-grids">
							<div class="bootstrap-tab-text-grid">
								<div class="bootstrap-tab-text-grid-left">
									<img src="<?php echo e(asset('frontEnd/images/admin.jpg')); ?>" alt=" " class="img-responsive">
								</div>
								<div class="bootstrap-tab-text-grid-right">
									<ul>
										<li><a href="#">Admin</a></li>
										
									</ul>
									<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis 
										suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem 
										vel eum iure reprehenderit.</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							
							<div class="add-review">
								<h4>add a review</h4>
								<?php echo Form::open(['url'=>'/productReview/save' , 'method'=>'POST','class'=>'form-horizontal']); ?>

								

									<input type="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}" name="reviewName" required="">
									<input type="email" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" name="reviewEmail" required="">
									
									<textarea type="text" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message...';}" name="reviewMessage" required=""></textarea>
									<input type="hidden" name="productId" id="productId" value="<?php echo e($ProductById->id); ?>">
									
								<input type="hidden" name="productName" id="productName" value="<?php echo e($ProductById->productName); ?>">


									<input type="submit" value="SEND">
								<?php echo Form::close(); ?>

							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //single -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>