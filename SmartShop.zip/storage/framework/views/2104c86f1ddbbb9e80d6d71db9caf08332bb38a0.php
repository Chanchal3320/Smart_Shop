<?php $__env->startSection('title'); ?>
Smart Shop || View Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <tr>
                                	<th>Product ID :</th>
                                	<th><?php echo e($product->id); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Name :</th>
                                	<th><?php echo e($product->productName); ?></th>
                                </tr>
                                <tr>
                                	<th>Category Name :</th>
                                	<th><?php echo e($product->categoryName); ?></th>
                                </tr>
                                <tr>
                                	<th>Manufacture Name :</th>
                                	<th><?php echo e($product->manufacturerName); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Price :</th>
                                	<th><?php echo e($product->productPrice); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Quantity :</th>
                                	<th><?php echo e($product->productQuantity); ?></th>
                                </tr>
                              
                                <tr>  
                                	<th>Product Short Description :</th>
                                	<th><?php echo e($product->productShortDescription); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Long Description :</th>
                                	<th><?php echo e($product->productLongDescription); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Image :</th>
                                	<th><img src="<?php echo e(asset($product->productImage)); ?>" alt="<?php echo e($product->productName); ?>" width="100" height="100"></th>
                                </tr>
                                <tr>
                                	<th>Publication Status :</th>
                                	<th><?php echo e($product->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></th>
                                </tr>
                            </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>