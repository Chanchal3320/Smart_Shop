<?php $__env->startSection('title'); ?>
Smart Shop || View Product Riview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Review For <strong>" <?php echo e($productReview->review_productName); ?> "</strong>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <tr>
                                	<th>Product ID :</th>
                                	<th><?php echo e($productReview->review_productID); ?></th>
                                </tr>
                                <tr>
                                	<th>Product Name :</th>
                                	<th><?php echo e($productReview->review_productName); ?></th>
                                </tr>
                                                               
                                <tr>
                                	<th>Product Price :</th>
                                	<th><?php echo e($productReview->productPrice); ?></th>
                                </tr>

                                <tr>
                                	<th>Reviewer Name :</th>
                                	<th><?php echo e($productReview->reviewer_name); ?></th>
                                </tr>

                                <tr>
                                	<th>Reviewer Email :</th>
                                	<th><?php echo e($productReview->reviewer_email); ?></th>
                                </tr>
                                <tr>
                                	<th>Reviewer Message :</th>
                                	<th><?php echo e($productReview->reviewer_message); ?></th>
                                </tr>
                               
                                <tr>
                                	<th>Product Image :</th>
                                	<th><img src="<?php echo e(asset($productReview->productImage)); ?>" alt="<?php echo e($productReview->review_productName); ?>" width="100" height="100"></th>
                                </tr>
                                
                            </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>