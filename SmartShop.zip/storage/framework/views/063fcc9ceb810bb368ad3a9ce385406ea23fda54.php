<?php $__env->startSection('title'); ?> 
Smart Shop || Customer Registration 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>

<hr>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-danger">Hello <b><?php echo e($customerById->lastName); ?></b> You Have To Enter Your Shipping Information..!! </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Shipping Form</div>

                <div class="panel-body">
    <?php echo Form::open(['url' => '/checkout/save-shipping' ,'method'=>'POST','class'=>'form-horizontal','name'=>'shippingForm']); ?>

                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('fullName') ? ' has-error' : ''); ?>">
                            <label for="fullName" class="col-md-4 control-label">Full Name</label>

                            <div class="col-md-6">
                                <input id="fullName" type="text" value="<?php echo e($customerById->firstName); ?>" class="form-control" name="fullName"  required autofocus>

                                <?php if($errors->has('fullName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fullName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        

                        <div class="form-group<?php echo e($errors->has('emailAddress') ? ' has-error' : ''); ?>">
                            <label for="emailAddress" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="emailAddress" type="email" value="<?php echo e($customerById->emailAddress); ?>" class="form-control" placeholder="Enter Email" name="emailAddress"  required>

                                <?php if($errors->has('emailAddress')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('emailAddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> 

                         <div class="form-group<?php echo e($errors->has('phoneNo') ? ' has-error' : ''); ?>">
                            <label for="phoneNo" class="col-md-4 control-label">Phone Number</label>
                         <div class="col-md-6">
                                <input id="phoneNo" type="text" value="<?php echo e($customerById->phoneNo); ?>" class="form-control" name="phoneNo" placeholder="Phone Number" required autofocus>

                                <?php if($errors->has('phoneNo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phoneNo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                            <label for="address" class="col-md-4 control-label"> Address</label>

                            <div class="col-md-6">
                                <!-- <input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" required > -->

                                <textarea name="address" placeholder="Address" id="address" class="form-control" cols="5" rows="2"><?php echo e($customerById->address); ?></textarea>

                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('distName') ? ' has-error' : ''); ?>">
                            <label for="distName" class="col-md-4 control-label">Dist. Name</label>

                            <div class="col-md-6">
                                <select name="distName" class="form-control">
                                    <option value="">--- Select District Name ---</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Sylhet">Sylhet</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Barisal">Barisal</option>
                                </select>

                                <?php if($errors->has('distName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('distName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>



                       

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    Submit
                                </button>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>



 

    </div>
</div>

<script>
        document.forms['shippingForm'].elements['distName'].value='<?php echo e($customerById->distName); ?>'
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>