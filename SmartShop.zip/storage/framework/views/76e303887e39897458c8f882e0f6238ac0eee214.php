<?php $__env->startSection('title'); ?>
Smart Shop || Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h3 style="text-align: center" class="text-success">
	
	<?php echo e(Session::get('message')); ?>

</h3>

<hr>

<div class="well">
 	<?php echo Form::open(['url' => '/product/save' ,'method'=>'POST','class'=>'form-horizontal', 'enctype'=>'multipart/form-data']); ?>

	
		<div class="form-group">
		    <label for="productName" class="col-sm-2 control-label">Product Name</label>
			    <div class="col-sm-10">
			    	<input type="text" name="productName" class="form-control" id="productName"  placeholder="Enter Product Name"> 
			    	<span class="text-danger"><?php echo e($errors->has('productName') ? $errors->first('productName'):""); ?></span>
			    </div>
		  </div>

		  <div class="form-group">
		    <label for="categoryId" class="col-sm-2 control-label">Category Name </label>
		    	<div class="col-sm-10">
		    		<select  name="categoryId" id="" class="form-control" >
		    			<option > Select Category Name </option>

		    			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    			<option value="<?php echo e($category->id); ?>"><?php echo e($category->categoryName); ?> </option>
		    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    		</select>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="manufacturerId" class="col-sm-2 control-label">Manufacturer Name </label>
		    	<div class="col-sm-10">
		    		<select  name="manufacturerId" id="" class="form-control" >
		    			<option > Select Manufacturer Name </option>

		    			<?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    			<option value="<?php echo e($manufacture->id); ?>"><?php echo e($manufacture->manufacturerName); ?> </option>
		    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    		</select>
		    	</div>
		  </div>
				
		  

		  <div class="form-group">
		    <label for="productPrice" class="col-sm-2 control-label">Product Price</label>
			    <div class="col-sm-10">
			    	<input type="number" name="productPrice" class="form-control" id="productPrice"  placeholder="Enter Product Price"> 
			    	<span class="text-danger"><?php echo e($errors->has('productPrice') ? $errors->first('productPrice'):""); ?></span>
			    </div>
		  </div> 

		   <div class="form-group">
		    <label for="productQuantity" class="col-sm-2 control-label">Product Quantity</label>
			    <div class="col-sm-10">
			    	<input type="number" name="productQuantity" class="form-control" id="productQuantity"  placeholder="Enter Product Quantity"> 
			    	<span class="text-danger"><?php echo e($errors->has('productQuantity') ? $errors->first('productQuantity'):""); ?></span>
			    </div>
		  </div>


		  <div class="form-group">
		    <label for="productShortDescription" class="col-sm-2 control-label">Product Short Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2" name="productShortDescription" class="form-control" id="productShortDescription" placeholder="Enter Product Short Description"></textarea>
			    	<span class="text-danger"><?php echo e($errors->has('productShortDescription') ? $errors->first('productShortDescription'):""); ?></span>

		    	</div>
		  </div>
		<div class="form-group">
		    <label for="productLongDescription" class="col-sm-2 control-label">Product Long Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2" name="productLongDescription" class="form-control" id="productShortDescription" placeholder="Enter Product Long Description"></textarea>
			    	<span class="text-danger"><?php echo e($errors->has('productLongDescription') ? $errors->first('productLongDescription'):""); ?></span>

		    	</div>
		  </div>
			
			<div class="form-group">
			    <label for="productImage" class="col-sm-2 control-label">Product Image</label>
				    <div class="col-sm-10">
				    	<input type="file"  name="productImage" accept="image/*"> 
				    	<span class="text-danger"><?php echo e($errors->has('productImage') ? $errors->first('productImage'):""); ?></span>
				    </div>
			  </div>


		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Save Product Info</button>
				</div>
			</div>
		  




	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>