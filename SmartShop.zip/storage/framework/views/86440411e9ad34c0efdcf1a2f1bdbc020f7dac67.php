<?php $__env->startSection('title'); ?>
Smart Shop || Product Review
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	

<h3 style="text-align: center" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h3>

            <div class="row">
                
                    <h1 class="page-header">Product Review Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Reviewer Name</th>
                                        <th>Reviewer Email</th>
                                        <th>Reviewer Message</th> 
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $i=1;
                                    ?>

                                    <?php $__currentLoopData = $productReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productReview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                	
                                    <tr class="odd gradeX">
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($productReview->review_productID); ?></td>
                                        <td><?php echo e($productReview->review_productName); ?></td>
                                        <td><?php echo e($productReview->reviewer_name); ?></td>
                                        <td><?php echo e($productReview->reviewer_email); ?></td>
                                        <td><?php echo e($productReview->reviewer_message); ?></td>
                                                                         
                                       
                                        
                                        
                                        <td>                                       	
                                        	
                                              <a href="<?php echo e(url('/productReview/view/'.$productReview->id )); ?>" class="btn btn-info" )" title="View">
                                                <span class="glyphicon glyphicon-eye-open"></span>
                                            </a>

                                            <a href="<?php echo e(url('/productReview/delete/'.$productReview->id )); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')" title="Delete">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>



                                           

                                         

                                        </td>
                                        
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>