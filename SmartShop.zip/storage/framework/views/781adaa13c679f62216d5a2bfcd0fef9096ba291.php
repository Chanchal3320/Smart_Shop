<?php $__env->startSection('title'); ?>
Smart Shop || Update Manufacture
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<hr>

<div class="well">
 	<?php echo Form::open(['url' => '/manufacture/update' ,'method'=>'POST','class'=>'form-horizontal','name'=>'editManufacturerForm']); ?>

	
		<div class="form-group">
		    <label for="manufacturerName" class="col-sm-2 control-label">Manufacturer Name</label>
			    <div class="col-sm-10">
			    	
			    	<input type="text" value="<?php echo e($manufactureById->manufacturerName); ?>" name="manufacturerName" class="form-control" id="manufacturerName"  placeholder="Enter Manufacturer Name"> 

			    	<input type="hidden" value="<?php echo e($manufactureById->id); ?>" name="manufaturerId" class="form-control"   > 

			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="manufacturerDescription" class="col-sm-2 control-label">Manufacturer Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2"   name="manufacturerDescription" class="form-control" id="manufacturerDescription" placeholder="Enter Manufacturer
		    		 Description"><?php echo e($manufactureById->manufacturerDescription); ?></textarea>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" value= "" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Update Catagory Info</button>
				</div>
			</div>
		  
	<script>
		document.forms['editManufacturerForm'].elements['publicationStatus'].value=<?php echo e($manufactureById->publicationStatus); ?>

		
	</script>



	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>