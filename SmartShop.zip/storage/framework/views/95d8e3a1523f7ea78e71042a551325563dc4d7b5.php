<!-- header -->
<div class="header">
	<div class="container">
		<ul>
			<li><span class="glyphicon glyphicon-time" aria-hidden="true"></span>Free and Fast Delivery</li>
			<li><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span>Free shipping On all orders</li>
			
			
			 <li>

			 	<div class="dropdown">
			 		<?php
			 			 $customerId = Session::get('customerId');
			 			 $customerName = Session::get('firstName');

			 		?>
				  
				  <p class="dropbtn" ><img src="<?php echo e(asset('frontEnd/images/user.jpg')); ?>" alt="" width="50" height="50">User<i class="fa fa-caret-down"></i></p>

				  <div class="dropdown-content">
					<?php
					if ($customerId != NULL) { ?>
						<a href="<?php echo e(url('/customerLogout')); ?>"><span class="glyphicon glyphicon-log-out"></span>LogOut</a>

						<?php
					}else{

						?>
					<a href="<?php echo e(url('/customerSignIn')); ?>"><span class="glyphicon glyphicon-log-in"></span>LogIn</a> <hr class="menu-hr">	


						<?php
					}
					?>
				    

				    			    
				  </div>
				  
				</div>
			 </li>


		</ul>
	</div>
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontEnd/images/logo3.jpg')); ?>"></a></h1>
		</div>
		<div class="col-md-6 header-middle">
			<form>
				<div class="search">
					<input type="search" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}" required="">
				</div>
				<div class="section_room">
					<!-- <select id="country" onchange="change_country(this.value)" class="frm-field required">
						<option value="null">All categories</option>
						<option value="null">Electronics</option>     
						<option value="AX">kids Wear</option>
						<option value="AX">Men's Wear</option>
						<option value="AX">Women's Wear</option>
						<option value="AX">Watches</option>
					</select> -->
					<select id="country" name="categoryName" id="categoryName" class="frm-field required">
						<option value="null">All categories</option>

						<?php $__currentLoopData = $publishedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publishedCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value=""> 
								
									
									<?php echo e($publishedCategory -> categoryName); ?>


								
							</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						
						
					</select>
				</div>
				<div class="sear-sub">
					<input type="submit" value=" ">
				</div>
				<div class="clearfix"></div>
			</form>
		</div>
		<div class="col-md-3 header-right footer-bottom">
			<ul>
				


				<li><a class="fb" href="#"></a></li>
				<li><a class="twi" href="#"></a></li>
				<li><a class="insta" href="#"></a></li>
				<li><a class="you" href="#"></a></li>

				


								
				</li>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- //header-bot -->
