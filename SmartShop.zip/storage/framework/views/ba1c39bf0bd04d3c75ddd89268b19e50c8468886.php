<?php $__env->startSection('title'); ?>
Smart Shop || Create Catagory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h3 style="text-align: center"></h3>

<hr>

<div class="well">
 	<?php echo Form::open(['url' => '/catagory/save' ,'method'=>'POST','class'=>'form-horizontal']); ?>

	
		<div class="form-group">
		    <label for="catagoryName" class="col-sm-2 control-label">Catagory Name</label>
			    <div class="col-sm-10">
			    	<input type="text" name="categoryName" class="form-control" id="catagoryName"  placeholder="Enter Catagory Name"> 
			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="catagoryDescription" class="col-sm-2 control-label">Catagory Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2" name="categoryDescription" class="form-control" id="catagoryDescription" placeholder="Catagory Description"></textarea>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Save Catagory Info</button>
				</div>
			</div>
		  




	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>