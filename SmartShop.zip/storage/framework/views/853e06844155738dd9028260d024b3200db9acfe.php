<?php $__env->startSection('title'); ?>
Smart Shop || Manage Manufacturer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	


<h3 style="text-align: center" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h3>

            <div class="row">
                
                    <h1 class="page-header">Manufacturer Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manufacturer Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Manufacturer Name</th>
                                        <th>Manufacturer Description</th>
                                        <th>Publication Status</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $__currentLoopData = $manufactures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="odd gradeX">
                                        <td><?php echo e($manufacture->id); ?></td>
                                        <td><?php echo e($manufacture->manufacturerName); ?></td>
                                        <td><?php echo e($manufacture->manufacturerDescription); ?></td>
                                        <td><?php echo e($manufacture->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td>
                                        	<a href="<?php echo e(url('/manufacture/edit/'.$manufacture->id )); ?>" class="btn btn-success">
                                        		<span class="glyphicon glyphicon-edit"></span>
                                        	</a>
                                        	<a href="<?php echo e(url('/manufacture/delete/'.$manufacture->id )); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')">
                                        		<span class="glyphicon glyphicon-trash"></span>
                                        	</a>

                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>