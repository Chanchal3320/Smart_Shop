<?php $__env->startSection('title'); ?> 
Smart Shop || Customer Registration 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>


<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success">
                <h1>Thanks For Your Order..!!</h1>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>