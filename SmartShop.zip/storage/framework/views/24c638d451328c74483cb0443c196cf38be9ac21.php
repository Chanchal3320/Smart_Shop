<?php $__env->startSection('title'); ?>
Smart Shop || Product Cart 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>

	<h3 class="shoppingBag">MY SHOPPING BAG</h3>
	<h4 style="text-align: center; margin-top: 10px; margin-bottom: 10px; font-weight: bold;" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h4>

	<table class="table table-bordered cart-table">
		<tr>
			<th>Remove</th>
			<th>SL</th>
			<th>Product Name</th>
			<th>Quantity</th>
			<th>Product Price</th>
			<th>SubTotal</th>
		</tr>
		<?php $i=1; 
		$total = 0;
		
		?>
			<?php $__currentLoopData = $cartProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo e(url('/delete-cart-product/'.$cartProduct->rowId)); ?>"><button class="btn btn-danger"><span class="glyphicon glyphicon-trash"></button></a></span></td>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($cartProduct->name); ?></td>
			<td>
				<?php echo Form::open(['url'=>'/cart-update' ,'method'=>'POST']); ?>

				<div class="input-group">
			      <input type="number" value="<?php echo e($cartProduct->qty); ?>" min="1" name="qty" class="form-control" >
			      <input type="hidden" value="<?php echo e($cartProduct->rowId); ?>" class="form-control" name="rowId" >
			      <span class="input-group-btn">
			        <button class="btn btn-primary" type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>

						</button>
			      </span>
			    </div>
			    <?php echo Form::close(); ?>

			</td>
			<td>BDT <?php echo e($cartProduct->price); ?></td>
			<?php 
				$subTotal = $cartProduct->price*$cartProduct->qty;
			?>
			<td>BDT <?php echo e($subTotal); ?></td>
		</tr>

		<?php

			$total= $total+$subTotal;

		 ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<div class="container">
		<div class="row">
			<div class="col-md-offset-5 col-md-7">
				<div class="totalPrice">
				<table class="table table-bordered shop-basket" >
					<tr>
						<th>SHOPPING &nbsp; BASKET</th>
					</tr>
					<tr>
						<td>Total <span class="price"> BDT <?php echo e($total); ?></span> </td>
						
					</tr>

					<?php 
						Session::put('orderTotal',$total);
						

					 ?>
				</table>
			</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
		<hr>
			<div class="backToShop">
				<a href="<?php echo e(url('/')); ?>" ><i class="fa fa-angle-left"></i>Back To Shopping</a>


				<?php 

					$customerId= Session::get('customerId');
					$shippingId= Session::get('shippingId');

					if ($customerId != null && $shippingId != null) {
						?>
						<a href="<?php echo e(url('/checkout/payment')); ?>"  >Check Out<i class="fa fa-angle-right"></i>  </a>
						<? } 
						
						else if($customerId != null){ ?>
						
						<a href="<?php echo e(url('/checkout/shipping')); ?>"  >Check Out<i class="fa fa-angle-right"></i></a>

						<?php
						 	}
						  else
						  	{ ?>
							<a href="<?php echo e(url('/checkout')); ?>"  >Check Out<i class="fa fa-angle-right"></i></a>
						<?php
						 }
						  ?>
			</div>

			

			

			
		
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>