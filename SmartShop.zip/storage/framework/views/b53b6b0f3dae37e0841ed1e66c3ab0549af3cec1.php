<?php $__env->startSection('title'); ?>
Smart Shop || Manage Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	

<h3 style="text-align: center" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h3>

            <div class="row">
                
                    <h1 class="page-header">Product Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        
                                        <th>Product Name</th>
                                        <th>Category Name</th>
                                        <th>Manufacture Name</th>
                                        <th>Product Price</th>
                                        <th>Product Quantity</th> 
                                        <th>Publication Status</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr class="odd gradeX">
                                        
                                        <td><?php echo e($product->productName); ?></td>
                                        <td><?php echo e($product->categoryName); ?></td>
                                        <td><?php echo e($product->manufacturerName); ?></td>
                                        <td><?php echo e($product->productPrice); ?></td>
                                        <td><?php echo e($product->productQuantity); ?></td>                                  
                                       
                                        
                                        <td><?php echo e($product->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td>
                                        	<a href="<?php echo e(url('/product/edit/'.$product->id )); ?>" class="btn btn-success" title="Edit">
                                        		<span class="glyphicon glyphicon-edit"></span>
                                        	</a>
                                        	<a href="<?php echo e(url('/product/delete/'.$product->id )); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')" title="Delete">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>


                                            <a href="<?php echo e(url('/product/view/'.$product->id )); ?>" class="btn btn-info" )" title="View">
                                                <span class="glyphicon glyphicon-eye-open"></span>
                                            </a>

                                           <!--  <a href="<?php echo e(url('/product/delete/'.$product->id )); ?>" class="btn btn-primary" onclick="return confirm('Are you sure you want to delete this ?')">
                                    		<span class="glyphicon glyphicon-eye-open"></span>
                                        	</a> -->

                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>