<?php $__env->startSection('title'); ?> 
Smart Shop || Update Catagory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="well">
 	<?php echo Form::open(['url' => '/category/update' ,'method'=>'POST','class'=>'form-horizontal','name'=>'editCategoryForm']); ?>

	
		<div class="form-group">
		    <label for="catagoryName" class="col-sm-2 control-label">Catagory Name</label>
			    <div class="col-sm-10">
			    	
			    	<input type="text" value="<?php echo e($categoryById->categoryName); ?>" name="categoryName" class="form-control" id="catagoryName"  placeholder="Enter Catagory Name"> 

			    	<input type="hidden" value="<?php echo e($categoryById->id); ?>" name="categoryId" class="form-control"   > 

			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="catagoryDescription" class="col-sm-2 control-label">Catagory Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2"   name="categoryDescription" class="form-control" id="categoryDescription" placeholder="Enter Catagory Description"><?php echo e($categoryById->categoryDescription); ?></textarea>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" value= "" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Update Catagory Info</button>
				</div>
			</div>
		  
	<script>
		document.forms['editCategoryForm'].elements['publicationStatus'].value=<?php echo e($categoryById->publicationStatus); ?>

		
	</script>



	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>