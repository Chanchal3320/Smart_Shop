<?php $__env->startSection('title'); ?>
Smart Shop || Manage Catagory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	

<h3 style="text-align: center" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h3>

            <div class="row">
                
                    <h1 class="page-header">Category Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default"> 
                        <div class="panel-heading">
                            Category Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Category Name</th>
                                        <th>Category Description</th>
                                        <th>Publication Status</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="odd gradeX">
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->categoryName); ?></td>
                                        <td><?php echo e($category->categoryDescription); ?></td>
                                        <td><?php echo e($category->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td>
                                        	<a href="<?php echo e(url('/category/edit/'.$category->id )); ?>" class="btn btn-success">
                                        		<span class="glyphicon glyphicon-edit"></span>
                                        	</a>
                                        	<a href="<?php echo e(url('/category/delete/'.$category->id )); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')">
                                        		<span class="glyphicon glyphicon-trash"></span>
                                        	</a>

                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>