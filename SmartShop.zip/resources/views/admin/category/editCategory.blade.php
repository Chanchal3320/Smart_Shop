@extends('admin.master')

@section('title') 
Smart Shop || Update Catagory
@endsection

@section('content')


 

<div class="well">
 	{!! Form::open(['url' => '/category/update' ,'method'=>'POST','class'=>'form-horizontal','name'=>'editCategoryForm']) !!}
	
		<div class="form-group">
		    <label for="catagoryName" class="col-sm-2 control-label">Catagory Name</label>
			    <div class="col-sm-10">
			    	
			    	<input type="text" value="{{ $categoryById->categoryName }}" name="categoryName" class="form-control" id="catagoryName"  placeholder="Enter Catagory Name"> 

			    	<input type="hidden" value="{{ $categoryById->id }}" name="categoryId" class="form-control"   > 

			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="catagoryDescription" class="col-sm-2 control-label">Catagory Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2"   name="categoryDescription" class="form-control" id="categoryDescription" placeholder="Enter Catagory Description">{{ $categoryById->categoryDescription }}</textarea>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" value= "" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Update Catagory Info</button>
				</div>
			</div>
		  
	<script>
		document.forms['editCategoryForm'].elements['publicationStatus'].value={{ $categoryById->publicationStatus }}
		
	</script>



	{!! Form::close() !!}
</div>
@endsection