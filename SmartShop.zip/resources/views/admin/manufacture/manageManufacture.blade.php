@extends('admin.master')

@section('title')
Smart Shop || Manage Manufacturer
@endsection

@section('content')

	


<h3 style="text-align: center" class="text-success">
    
    {{Session::get('message')}}
</h3>

            <div class="row">
                
                    <h1 class="page-header">Manufacturer Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manufacturer Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th> 
                                        <th>Manufacturer Name</th>
                                        <th>Manufacturer Description</th>
                                        <th>Publication Status</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	@foreach($manufactures as $manufacture)
                                    <tr class="odd gradeX">
                                        <td>{{$manufacture->id}}</td>
                                        <td>{{$manufacture->manufacturerName}}</td>
                                        <td>{{$manufacture->manufacturerDescription}}</td>
                                        <td>{{$manufacture->publicationStatus == 1 ? 'Published' : 'Unpublished' }}</td>
                                        <td>
                                        	<a href="{{ url('/manufacture/edit/'.$manufacture->id )}}" class="btn btn-success">
                                        		<span class="glyphicon glyphicon-edit"></span>
                                        	</a>
                                        	<a href="{{ url('/manufacture/delete/'.$manufacture->id )}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')">
                                        		<span class="glyphicon glyphicon-trash"></span>
                                        	</a>

                                        </td>
                                        
                                    </tr>
                                    @endforeach

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

@endsection