@extends('admin.master')

@section('title')
Smart Shop || Create Manufacture
@endsection

@section('content')
<h3 style="text-align: center" class="text-success">
	
	{{Session::get('message')}}
</h3>

<hr>

<div class="well">
 	{!! Form::open(['url' => '/manufacture/save' ,'method'=>'POST','class'=>'form-horizontal']) !!}
	
		<div class="form-group">
		    <label for="manufacturerName" class="col-sm-2 control-label">Manufacturer Name</label>
			    <div class="col-sm-10">
			    	<input type="text" name="manufacturerName" class="form-control" id="manufacturerName"  placeholder="Enter Manufacturer Name"> 
			    	<span class="text-danger">{{$errors->has('manufacturerName') ? $errors->first('manufacturerName'):""}}</span>
			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="manufacturerDescription" class="col-sm-2 control-label">Manufacturer Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2" name="manufacturerDescription" class="form-control" id="manufacturerDescription" placeholder="Enter Manufacturer Description"></textarea>
			    	<span class="text-danger">{{$errors->has('manufacturerDescription') ? $errors->first('manufacturerDescription'):""}}</span>

		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Save Manufacturer Info</button>
				</div>
			</div>
		  




	{!! Form::close() !!}
</div>

@endsection