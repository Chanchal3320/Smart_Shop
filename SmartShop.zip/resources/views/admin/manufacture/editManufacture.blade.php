@extends('admin.master')

@section('title')
Smart Shop || Update Manufacture
@endsection

@section('content')


<hr>

<div class="well">
 	{!! Form::open(['url' => '/manufacture/update' ,'method'=>'POST','class'=>'form-horizontal','name'=>'editManufacturerForm']) !!}
	
		<div class="form-group">
		    <label for="manufacturerName" class="col-sm-2 control-label">Manufacturer Name</label>
			    <div class="col-sm-10">
			    	
			    	<input type="text" value="{{ $manufactureById->manufacturerName }}" name="manufacturerName" class="form-control" id="manufacturerName"  placeholder="Enter Manufacturer Name"> 

			    	<input type="hidden" value="{{ $manufactureById->id }}" name="manufaturerId" class="form-control"   > 

			    </div>
		  </div>
				
		  <div class="form-group">
		    <label for="manufacturerDescription" class="col-sm-2 control-label">Manufacturer Description</label>
		    	<div class="col-sm-10">
		    		<textarea  cols="5" rows="2"   name="manufacturerDescription" class="form-control" id="manufacturerDescription" placeholder="Enter Manufacturer
		    		 Description">{{ $manufactureById->manufacturerDescription }}</textarea>
		    	</div>
		  </div>

		  <div class="form-group">
		    <label for="publicationStatus" class="col-sm-2 control-label">Publication Status </label>
		    	<div class="col-sm-10">
		    		<select name="publicationStatus" value= "" name="publicationStatus" id="" class="form-control" >
		    			<option value="#">Select Publication Status</option>
		    			<option value="1">Published</option>
		    			<option value="0">UnPublished</option>
		    		</select>
		    	</div>
		  </div>


			<div class="form-group">
				<div class="col-sm-10 col-sm-offset-2">
					<button type="submit" name="btn" class="btn btn-success btn-block">Update Catagory Info</button>
				</div>
			</div>
		  
	<script>
		document.forms['editManufacturerForm'].elements['publicationStatus'].value={{ $manufactureById->publicationStatus }}
		
	</script>



	{!! Form::close() !!}
</div>
@endsection