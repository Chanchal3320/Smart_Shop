@extends('admin.master')

@section('title')
Smart Shop || Manage Product
@endsection

@section('content')

	

<h3 style="text-align: center" class="text-success">
    
    {{Session::get('message')}}
</h3>

            <div class="row">
                
                    <h1 class="page-header">Product Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        
                                        <th>Product Name</th>
                                        <th>Category Name</th>
                                        <th>Manufacture Name</th>
                                        <th>Product Price</th>
                                        <th>Product Quantity</th> 
                                        <th>Publication Status</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	@foreach($products as $product) 
                                    <tr class="odd gradeX">
                                        
                                        <td>{{$product->productName}}</td>
                                        <td>{{$product->categoryName }}</td>
                                        <td>{{$product->manufacturerName}}</td>
                                        <td>{{$product->productPrice}}</td>
                                        <td>{{$product->productQuantity}}</td>                                  
                                       
                                        
                                        <td>{{$product->publicationStatus == 1 ? 'Published' : 'Unpublished' }}</td>
                                        <td>
                                        	<a href="{{ url('/product/edit/'.$product->id )}}" class="btn btn-success" title="Edit">
                                        		<span class="glyphicon glyphicon-edit"></span>
                                        	</a>
                                        	<a href="{{ url('/product/delete/'.$product->id )}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')" title="Delete">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>


                                            <a href="{{ url('/product/view/'.$product->id )}}" class="btn btn-info" )" title="View">
                                                <span class="glyphicon glyphicon-eye-open"></span>
                                            </a>

                                           <!--  <a href="{{ url('/product/delete/'.$product->id )}}" class="btn btn-primary" onclick="return confirm('Are you sure you want to delete this ?')">
                                    		<span class="glyphicon glyphicon-eye-open"></span>
                                        	</a> -->

                                        </td>
                                        
                                    </tr>
                                    @endforeach

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

@endsection