@extends('admin.master')

@section('title')
Smart Shop || View Product
@endsection

@section('content') 
<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <tr>
                                	<th>Product ID :</th>
                                	<th>{{$product->id}}</th>
                                </tr>
                                <tr>
                                	<th>Product Name :</th>
                                	<th>{{$product->productName}}</th>
                                </tr>
                                <tr>
                                	<th>Category Name :</th>
                                	<th>{{$product->categoryName}}</th>
                                </tr>
                                <tr>
                                	<th>Manufacture Name :</th>
                                	<th>{{$product->manufacturerName}}</th>
                                </tr>
                                <tr>
                                	<th>Product Price :</th>
                                	<th>{{$product->productPrice}}</th>
                                </tr>
                                <tr>
                                	<th>Product Quantity :</th>
                                	<th>{{$product->productQuantity}}</th>
                                </tr>
                              
                                <tr>  
                                	<th>Product Short Description :</th>
                                	<th>{{$product->productShortDescription}}</th>
                                </tr>
                                <tr>
                                	<th>Product Long Description :</th>
                                	<th>{{$product->productLongDescription}}</th>
                                </tr>
                                <tr>
                                	<th>Product Image :</th>
                                	<th><img src="{{asset($product->productImage)}}" alt="{{$product->productName}}" width="100" height="100"></th>
                                </tr>
                                <tr>
                                	<th>Publication Status :</th>
                                	<th>{{$product->publicationStatus == 1 ? 'Published' : 'Unpublished' }}</th>
                                </tr>
                            </table>

@endsection