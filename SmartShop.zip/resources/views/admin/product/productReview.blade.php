@extends('admin.master')

@section('title')
Smart Shop || Product Review
@endsection

@section('content')

	

<h3 style="text-align: center" class="text-success">
    
    {{Session::get('message')}}
</h3>

            <div class="row">
                
                    <h1 class="page-header">Product Review Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Reviewer Name</th>
                                        <th>Reviewer Email</th>
                                        <th>Reviewer Message</th> 
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $i=1;
                                    ?>

                                    @foreach($productReviews as $productReview)
                                	
                                    <tr class="odd gradeX">
                                        <td>{{$i++}}</td>
                                        <td>{{$productReview->review_productID }}</td>
                                        <td>{{$productReview->review_productName }}</td>
                                        <td>{{$productReview->reviewer_name  }}</td>
                                        <td>{{$productReview->reviewer_email }}</td>
                                        <td>{{$productReview->reviewer_message }}</td>
                                                                         
                                       
                                        
                                        
                                        <td>                                       	
                                        	
                                              <a href="{{ url('/productReview/view/'.$productReview->id )}}" class="btn btn-info" )" title="View">
                                                <span class="glyphicon glyphicon-eye-open"></span>
                                            </a>

                                            <a href="{{ url('/productReview/delete/'.$productReview->id )}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')" title="Delete">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>



                                           

                                         

                                        </td>
                                        
                                    </tr>
                                    
                                @endforeach
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

@endsection