@extends('admin.master')

@section('title') 
Smart Shop || Update User
@endsection

@section('content')




<div class="well">
    {!! Form::open(['url' => '/user/update' ,'method'=>'POST','class'=>'form-horizontal','name'=>'editUserForm']) !!}
    
                         {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" value="{{$userById->name}}" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <input type="hidden" value="{{ $userById->id }}" name="userId" class="form-control"   > 
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" value="{{$userById->email}}"class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> 


                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Address</label>

                            <div class="col-md-6">
                                <!-- <input id="address" type="text" class="form-control" name="address" value="{{ old('address') }}" required > -->

                                <textarea name="address"  id="address" class="form-control" cols="2" rows="2">{{$userById->address}}</textarea>

                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>



                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-success btn-large">
                                    Update User Info
                                </button>
                            </div>
                        </div>


    {!! Form::close() !!}
</div>
@endsection