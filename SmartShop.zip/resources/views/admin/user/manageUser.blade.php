@extends('admin.master')

@section('title')
Smart Shop || Manage User
@endsection

@section('content')

	


            <div class="row">
                
                    <h1 class="page-header">User Table</h1>
         
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            User Manage
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                             <h2>Total {{$users->total()}} users Exists.</h2>
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>User Name</th>
                                        <th>User Email</th>
                                        <th>User Address</th>
                                        <th>Action</th>
                                       <!--  <th>Engine version</th> -->
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=1 ?>
                                	@foreach($users as $user)
                                    <tr class="odd gradeX">
                                        <td>{{$i++}}</td>
                                        <td>{{$user->name}}</td>
                                        <td>{{$user->email}}</td>
                                        <td>{{$user->address}}</td>
                                        
                                        
                                        <td>
                                            <a href="{{ url('/user/edit/'.$user->id )}}" class="btn btn-success">
                                                <span class="glyphicon glyphicon-edit"></span>
                                            </a>
                                            <a href="{{ url('/user/delete/'.$user->id )}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ?')">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>

                                        </td>
                                        
                                    </tr>
                                    @endforeach

                                </tbody>
                                <div>
                                    {{$users->links()}}
                                </div>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
               

@endsection