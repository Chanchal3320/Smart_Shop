@extends('frontEnd.master')

@section('title')
Smart Shop || Product Cart 
@endsection

@section('mainContent')

	<h3 class="shoppingBag">MY SHOPPING BAG</h3>
	<h4 style="text-align: center; margin-top: 10px; margin-bottom: 10px; font-weight: bold;" class="text-success">
    
    {{Session::get('message')}} 
</h4>

	<table class="table table-bordered cart-table">
		<tr>
			<th>Remove</th>
			<th>SL</th>
			<th>Product Name</th>
			<th>Quantity</th> 
			<th>Product Price</th>
			<th>SubTotal</th>
		</tr>
		<?php $i=1; 
		$total = 0;
		
		?>
			@foreach($cartProducts as $cartProduct)
		<tr>
			<td><a href="{{url('/delete-cart-product/'.$cartProduct->rowId)}}"><button class="btn btn-danger"><span class="glyphicon glyphicon-trash"></button></a></span></td>
			<td>{{$i++}}</td>
			<td>{{$cartProduct->name}}</td>
			<td>
				{!!Form::open(['url'=>'/cart-update' ,'method'=>'POST'])!!}
				<div class="input-group">
			      <input type="number" value="{{$cartProduct->qty}}" min="1" name="qty" class="form-control" >
			      <input type="hidden" value="{{$cartProduct->rowId}}" class="form-control" name="rowId" >
			      <span class="input-group-btn">
			        <button class="btn btn-primary" type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>

						</button>
			      </span>
			    </div>
			    {!!Form::close()!!}
			</td>
			<td>BDT {{$cartProduct->price}}</td>
			<?php 
				$subTotal = $cartProduct->price*$cartProduct->qty;
			?>
			<td>BDT {{$subTotal}}</td>
		</tr>

		<?php

			$total= $total+$subTotal;

		 ?>

		@endforeach
	</table>

	<div class="container">
		<div class="row">
			<div class="col-md-offset-5 col-md-7">
				<div class="totalPrice">
				<table class="table table-bordered shop-basket" >
					<tr>
						<th>SHOPPING &nbsp; BASKET</th>
					</tr>
					<tr>
						<td>Total <span class="price"> BDT {{$total}}</span> </td>
						
					</tr>

					<?php 
						Session::put('orderTotal',$total);
						

					 ?>
				</table>
			</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
		<hr>
			<div class="backToShop">
				<a href="{{url('/')}}" ><i class="fa fa-angle-left"></i>Back To Shopping</a>


				<?php 

					$customerId= Session::get('customerId');
					$shippingId= Session::get('shippingId');

					if ($customerId != null && $shippingId != null) {
						?>
						<a href="{{url('/checkout/payment')}}"  >Check Out<i class="fa fa-angle-right"></i>  </a>
						<? } 
						
						else if($customerId != null){ ?>
						
						<a href="{{url('/checkout/shipping')}}"  >Check Out<i class="fa fa-angle-right"></i></a>

						<?php
						 	}
						  else
						  	{ ?>
							<a href="{{url('/checkout')}}"  >Check Out<i class="fa fa-angle-right"></i></a>
						<?php
						 }
						  ?>
			</div>

			

			

			
		
	
	
@endsection