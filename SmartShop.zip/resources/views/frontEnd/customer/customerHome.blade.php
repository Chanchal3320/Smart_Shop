@extends('frontEnd.master')

@section('title') 
Smart Shop || Customer Home
@endsection

@section('mainContent')


<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success">
                <h1>Thanks For Your Order..!!</h1>
            </div>
        </div>
    </div>
</div>

@endsection
