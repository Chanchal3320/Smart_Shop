@extends('frontEnd.master')

@section('title') 
Smart Shop || Customer Registration 
@endsection

@section('mainContent')

<hr>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-danger">You have to Login First for Checkout...!! If You Are Not  Registratered Then Sign Up Please..!!</div> 
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6 ">
            <div class="panel panel-default">
                <div class="panel-heading">Customer Resistration Form</div>

                <div class="panel-body">
    {!! Form::open(['url' => '/checkout/sign-up' ,'method'=>'POST','class'=>'form-horizontal']) !!}
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('firstName') ? ' has-error' : '' }}">
                            <label for="firstName" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="firstName" type="text" class="form-control" name="firstName" placeholder="First Name" required autofocus>

                                @if ($errors->has('firstName'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('firstName') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('lastName') ? ' has-error' : '' }}">
                            <label for="lastName" class="col-md-4 control-label">Last Name</label>

                            <div class="col-md-6">
                                <input id="lastName" type="text" class="form-control" name="lastName" placeholder="Last Name" required autofocus>

                                @if ($errors->has('lastName'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('lastName') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" placeholder="Enter Email" name="emailAddress"  required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> 

                         <div class="form-group{{ $errors->has('phoneNo') ? ' has-error' : '' }}">
                            <label for="phoneNo" class="col-md-4 control-label">Phone Number</label>
                         <div class="col-md-6">
                                <input id="phoneNo" type="text" class="form-control" name="phoneNo" placeholder="Phone Number" required autofocus>

                                @if ($errors->has('phoneNo'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phoneNo') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label for="address" class="col-md-4 control-label"> Address</label>

                            <div class="col-md-6">
                                <!-- <input id="address" type="text" class="form-control" name="address" value="{{ old('address') }}" required > -->

                                <textarea name="address" placeholder="Address" id="address" class="form-control" cols="5" rows="2"></textarea>

                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('distName') ? ' has-error' : '' }}">
                            <label for="distName" class="col-md-4 control-label">Dist. Name</label>

                            <div class="col-md-6">
                                <select name="distName" class="form-control">
                                    <option value="">--- Select District Name ---</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Sylhet">Sylhet</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Barisal">Barisal</option>
                                </select>

                                @if ($errors->has('distName'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('distName') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>



                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" placeholder="Enter Password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    Submit
                                </button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>



 <div class="col-md-6 ">
            <div class="panel panel-default">
                <div class="panel-heading">Login Form</div>

                <div class="panel-body">
    {!! Form::open(['url' => '/checkout/sign-in' ,'method'=>'POST','class'=>'form-horizontal']) !!}
                        {{ csrf_field() }}

                        

                        <div class="form-group{{ $errors->has('emailAddress') ? ' has-error' : '' }}">
                            <label for="emailAddress" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="emailAddress" type="email" class="form-control" placeholder="Enter Email" name="emailAddress"  required>

                                @if ($errors->has('emailAddress'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('emailAddress') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" placeholder="Enter Password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    Login
                                </button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>


    </div>
</div>
@endsection
