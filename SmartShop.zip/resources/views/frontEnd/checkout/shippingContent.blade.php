@extends('frontEnd.master')

@section('title') 
Smart Shop || Customer Registration 
@endsection

@section('mainContent')

<hr>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-danger">Hello <b>{{$customerById->lastName}}</b> You Have To Enter Your Shipping Information..!! </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Shipping Form</div>

                <div class="panel-body">
    {!! Form::open(['url' => '/checkout/save-shipping' ,'method'=>'POST','class'=>'form-horizontal','name'=>'shippingForm']) !!}
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('fullName') ? ' has-error' : '' }}">
                            <label for="fullName" class="col-md-4 control-label">Full Name</label>

                            <div class="col-md-6">
                                <input id="fullName" type="text" value="{{$customerById->firstName}}" class="form-control" name="fullName"  required autofocus>

                                @if ($errors->has('fullName'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('fullName') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        

                        <div class="form-group{{ $errors->has('emailAddress') ? ' has-error' : '' }}">
                            <label for="emailAddress" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="emailAddress" type="email" value="{{$customerById->emailAddress}}" class="form-control" placeholder="Enter Email" name="emailAddress"  required>

                                @if ($errors->has('emailAddress'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('emailAddress') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> 

                         <div class="form-group{{ $errors->has('phoneNo') ? ' has-error' : '' }}">
                            <label for="phoneNo" class="col-md-4 control-label">Phone Number</label>
                         <div class="col-md-6">
                                <input id="phoneNo" type="text" value="{{$customerById->phoneNo}}" class="form-control" name="phoneNo" placeholder="Phone Number" required autofocus>

                                @if ($errors->has('phoneNo'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phoneNo') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label for="address" class="col-md-4 control-label"> Address</label>

                            <div class="col-md-6">
                                <!-- <input id="address" type="text" class="form-control" name="address" value="{{ old('address') }}" required > -->

                                <textarea name="address" placeholder="Address" id="address" class="form-control" cols="5" rows="2">{{$customerById->address}}</textarea>

                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('distName') ? ' has-error' : '' }}">
                            <label for="distName" class="col-md-4 control-label">Dist. Name</label>

                            <div class="col-md-6">
                                <select name="distName" class="form-control">
                                    <option value="">--- Select District Name ---</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Sylhet">Sylhet</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Barisal">Barisal</option>
                                </select>

                                @if ($errors->has('distName'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('distName') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>



                       

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    Submit
                                </button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>



 

    </div>
</div>

<script>
        document.forms['shippingForm'].elements['distName'].value='{{$customerById->distName}}'
        
    </script>
@endsection
