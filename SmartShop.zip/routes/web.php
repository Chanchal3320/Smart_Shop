<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


/* Front End */
Auth::routes(); 
Route::get('/dashboard', 'HomeController@index')->name('dashboard');


Route::get('/','Welcome_Controller@index');

Route::get('/categoryView/{id}','Welcome_Controller@category');

Route::get('/category','Welcome_Controller@viewCategory');

Route::get('/contact','Welcome_Controller@contact');
Route::get('/product_details/{id}','Welcome_Controller@productDetails');

/*----------Shopping Cart-----------*/
Route::post('/cart-add','CartController@addToCart');
Route::get('/show-cart','CartController@cartShow');

Route::post('/cart-update','CartController@updateCart');
Route::get('/delete-cart-product/{rowId}','CartController@deleteCart');

/*-------Check Out----*/
Route::get('/checkout','CheckoutController@index');

Route::get('/checkout/shipping','CheckoutController@showShippingForm');
Route::post('/checkout/save-shipping','CheckoutController@saveShippingInfo');
Route::get('/checkout/payment','CheckoutController@showPaymentForm');
Route::post('/checkout/save-order','CheckoutController@saveOrderInfo');
Route::get('/check/my-home','CheckoutController@customerHome');


Route::post('/checkout/sign-up','CustomerLoginController@customerSignUp');
Route::get('/customerSignIn','CustomerLoginController@customerSignInForm');
Route::get('/customerLogout','CustomerLoginController@customerLogout');
Route::post('/checkout/sign-in','CustomerLoginController@customerSignIn');


/*----------- Menu Area -----------------*/

Route::get('/electronics','Welcome_Controller@menuElectronics');




/*------------  Admin Panel ------ */


/*  Catagory Info */
//Route::get('/category/add','CategoryController@createCategory')->middleware('AuthenticateMiddleware');
Route::post('/category/save','CategoryController@storeCategory');
Route::post('/category/update','CategoryController@updateCategory');

/* Manufacture Info */

Route::post('/manufacture/save','ManufactureController@storeManufacture');
Route::post('/manufacture/update','ManufactureController@updateManufacture');



/* Product Info */

Route::post('/product/save','ProductController@storeProduct');
Route::post('/product/update','ProductController@updateProduct');

/*----- User Info -------*/

Route::post('/user/update','UserController@updateUser');


 



/*-- Middleware Group --*/
Route::group(['middleware' => 'AuthenticateMiddleware'], function() {
					/*----- Category--------*/
   Route::get('/category/add','CategoryController@createCategory');
   Route::get('/category/manage','CategoryController@manegeCategory');
   Route::get('/category/edit/{id}','CategoryController@editCategory');
   Route::get('/category/delete/{id}','CategoryController@deleteCategory');

					/*----- Manufacturer--------*/

   Route::get('/manufacture/add','ManufactureController@createManufacture');
   Route::get('/manufacture/manage','ManufactureController@manegeManufacture');
   Route::get('/manufacture/edit/{id}','ManufactureController@editManufacture');
   Route::get('/manufacture/delete/{id}','ManufactureController@deleteManufacture');

					/*----- Product--------*/

	Route::get('/product/add','ProductController@createProduct');
	Route::get('/product/manage','ProductController@manegeProduct');


	Route::get('/product/edit/{id}','ProductController@editProduct');
	Route::get('/product/delete/{id}','ProductController@deleteProduct');
	Route::get('/product/view/{id}','ProductController@viewProduct');

	/*---------Product Review-------*/
	Route::get('/productReview/manage','ProductReviewController@manegeProductReview');
	Route::post('/productReview/save','ProductReviewController@saveProductReview');
	// Route::get('/productReview/store','ProductReviewController@storeProductReview');
	Route::get('/productReview/view/{id}','ProductReviewController@viewProductReview');
	Route::get('/productReview/delete/{id}','ProductReviewController@deleteProductReview');




	/*----------User-----------*/


Route::get('/user/manage','UserController@manegeUser');
Route::get('/user/edit/{id}','UserController@editUser');
Route::get('/user/delete/{id}','UserController@deleteUser');






});