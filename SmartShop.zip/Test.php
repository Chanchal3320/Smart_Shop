<?php 

public function customerSignIn(Request $request)
 {
     // dd($request->all());

     // exit();

    //Validate the form 
    $this->validate($request,[
        'emailAddress' => 'required|email',
        'password' => 'required|min:6',

    ]);

    $remember =  $request->remember;
    //Attemt to login user
    if (Auth::guard('customer')->attempt($this->credentials(),$remember)) {
        return redirect()->intended(url('frontEnd.checkout.shippingContent'));
    }
    
    else {
        return redirect()->back()->withInput($request->only('emailAddress','remember'));
    }

     
    //if successfull then redirect to the intended page



    //if unsuccessful then back to the login form


 }


protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }


      public function username()
    {
        return 'emailAddress';
    }
